export class Proizvod {
    constructor(id, naziv,cena) {
        this.id = id;
        this.naziv = naziv;
        this.cena=cena;
        
        this.miniKontejner1 = null;
        this.miniKontejner0= null;
       
    }
}

